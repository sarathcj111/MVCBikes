﻿using MVCBike.Models;
using System.Collections.Generic;

namespace MVCBike.Repository.Interface
{
    public interface ICompanyRepository
    {
            List<CompanyModel> AddNewCompany(CompanyModel companyModel);
            List<CompanyModel> GetAllCompany();
            List<CompanyModel> EditCompany(CompanyModel Company);
            bool DeleteCompany(int companyId, out List<CompanyModel> companys);
            List<CompanyModel> Search(string search);
            CompanyModel SearchCompany(int CompanyId);
            IEnumerable<CompanyModel> SearchLikeCompany(string Company);
            IEnumerable<CompanyModel> SearchLikePatternCompany(string Company);

    }
}
