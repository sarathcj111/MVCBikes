﻿using Microsoft.Extensions.Configuration;
using MVCBike.Models;
using MVCBike.Repository.Interface;
using System.Collections.Generic;
using MVCBike.Helper;
using System.Linq;
using System;

namespace MVCBike.Repository
{
    public class BikeRepository: IBikeRepository
    {
        private readonly IConfiguration _config;
        private HelperClass _helper;
        public BikeRepository(IConfiguration config)
        {
            _config = config;
            _helper = new HelperClass();
        }
        private List<BikeModel> bikeList = new List<BikeModel>();
        private List<BikeModel> GenerateBikeList()
        {
           
            for (var i = 0; i <= 100; i++)
            {
                if (_config.GetValue<int>($"Bike{i + 1}:Id") > 0)
                {
                BikeModel bike = new BikeModel();
                bike.Id = _config.GetValue<int>($"Bike{i + 1}:Id");
                bike.Company = _config.GetValue<string>($"Bike{i + 1}:Company");
                bike.Model = _config.GetValue<string>($"Bike{i + 1}:Model");
                bike.Price = _config.GetValue<decimal>($"Bike{i + 1}:Price");
                bikeList.Add(bike);
                }
                else
                    break;
            }
            return bikeList;
        }
        public List<BikeModel> GetAllBikes()
        {
            GenerateBikeList();
            return bikeList;
        }
        /* public List<BikeModel> EditBike(int bikeId)
         {
             var bikes = GenerateBikeList();
             var bike = bikes.Find(x => x.Id == bikeId);
             bike.Model = "edited " + bike.Model;
             return bikes;
         }*/

        public List<BikeModel> EditBike(BikeModel bike)
        {
            var bikes = GenerateBikeList();
            var objBike = bikes.Find(x => x.Id == bike.Id);
            var companies = new CompanyRepository(_config);
            var companyName = companies.GetAllCompany().Find(x => x.Id == Convert.ToInt32(bike.Company)).Name;
            bike.Company = companyName;
            //objBook.Title = book.Title;
            //objBook.Genre = book.Genre;
            //objBook.Price = book.Price;
            //objBook.Company = book.Company;
            bikes.Remove(bikes.Find(x => x.Id == bike.Id));
            _helper.RemoveFromJson(bike.Id, "Bike");

            bikes.Add(bike);
            _helper.AddtoJson(bike);

            return bikes;
        }
        public bool DeleteBike(int bikeId, out List<BikeModel> bikes)
        {
            bikes = GenerateBikeList();
            bikes.Remove(bikes.Find(x => x.Id == bikeId));
            var bike = bikes.Find(x => x.Id == bikeId);
            if (bike == null)
            {
                _helper.RemoveFromJson(bikeId, "Bike");
                return true;
            }
            else
                return false;
        }
        public List<BikeModel> AddNewBike(BikeModel bike)
        {
            var bikes = GenerateBikeList();
            bike.Id = bikes.Count + 1;
            bikes.Add(bike);
            _helper.AddtoJson(bike);
            return bikes;
        }

         public List<BikeModel> Search(string search)
         {
                var bikes = GenerateBikeList();
                var bike = bikes.Where(x => x.Company == search || search == null).ToList();
                return bike;
           }
        }
                
    }
   

