﻿using System.Collections.Generic;

namespace MVCBike.Models
{
    public class SearchModel
    {
        public IEnumerable<BikeModel> BikeModel { get; set; }
        public IEnumerable<CompanyModel> CompanyModel { get; set; }
    }
}
