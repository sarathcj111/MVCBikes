﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MVCBike.Models;
using MVCBike.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace MVCBike.Controllers
{
    public class SearchController : Controller
    {
        private readonly ILogger<SearchController> _logger;
        private readonly IBikeRepository _IBikeRepository;
        private readonly ICompanyRepository _ICompanyRepository;
        public SearchController(ILogger<SearchController> logger, IBikeRepository iBikeRepository, ICompanyRepository iCompanyRepository)
        {
            _logger = logger;
            _IBikeRepository = iBikeRepository;
            _ICompanyRepository = iCompanyRepository;
        }
        public IActionResult Index(string search)
        {
            SearchModel newmodel = new SearchModel();
            newmodel.BikeModel = _IBikeRepository.Search(search);
            newmodel.CompanyModel = _ICompanyRepository.Search(search);
            return View(newmodel);
        }
    }
}
