﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MVCBike.Models;
using MVCBike.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace MVCBike.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IBikeRepository _IBikeRepository;
        private readonly ICompanyRepository _ICompanyRepository;

        public HomeController(ILogger<HomeController> logger, IBikeRepository iBikeRepository, ICompanyRepository iCompanyRepository)
        {
            _logger = logger;
            _IBikeRepository = iBikeRepository;
            _ICompanyRepository = iCompanyRepository;
        }
        public IActionResult Index()
        {
            var bikes = _IBikeRepository.GetAllBikes();
            return View(bikes);
        }

        public IActionResult EditBike(BikeModel bike)
        {
            var bikeList = _IBikeRepository.EditBike(bike);
            return View("Index", bikeList);
        }

        public IActionResult OpenEditBikePage(int bikeId)
        {
            var bikeList = _IBikeRepository.GetAllBikes();
            var bike = bikeList.Find(x => x.Id == bikeId);
            var companies = _ICompanyRepository.GetAllCompany();
            ViewBag.ListItem = companies;

            return View("EditBike", bike);
        }

        public IActionResult DeleteBike(int bikeId)
        {
            var isbike = _IBikeRepository.DeleteBike(bikeId, out List<BikeModel> bikes);
            return View("Index", bikes);
        }
        public IActionResult OpenAddBikePage()
        {
            var companies = _ICompanyRepository.GetAllCompany();
            ViewBag.ListItem = companies;
            return View("AddBike");
        }

        public IActionResult AddBike(BikeModel bike)
        {
            var bikes = _IBikeRepository.AddNewBike(bike);
            return View("Index", bikes);
        }

        public IActionResult Privacy()
        {
            return View();
        }
       
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
